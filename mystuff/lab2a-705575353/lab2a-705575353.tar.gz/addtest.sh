# !/bin/sh

./lab2_add  --threads=1 --iterations=100
./lab2_add  --threads=1 --iterations=1000
./lab2_add  --threads=1 --iterations=10000
./lab2_add  --threads=1 --iterations=100000
./lab2_add  --threads=2 --iterations=100
./lab2_add  --threads=2 --iterations=1000
./lab2_add  --threads=2 --iterations=10000
./lab2_add  --threads=2 --iterations=100000
./lab2_add  --threads=4 --iterations=100
./lab2_add  --threads=4 --iterations=1000
./lab2_add  --threads=4 --iterations=10000
./lab2_add  --threads=4 --iterations=100000
./lab2_add  --threads=8 --iterations=100
./lab2_add  --threads=8 --iterations=1000
./lab2_add  --threads=8 --iterations=10000
./lab2_add  --threads=8 --iterations=100000

./lab2_add  --yield --threads=2 --iterations=10
./lab2_add  --yield --threads=2 --iterations=20
./lab2_add  --yield --threads=2 --iterations=40
./lab2_add  --yield --threads=2 --iterations=80
./lab2_add  --yield --threads=2 --iterations=100
./lab2_add  --yield --threads=2 --iterations=1000
./lab2_add  --yield --threads=2 --iterations=10000
./lab2_add  --yield --threads=2 --iterations=100000
./lab2_add  --yield --threads=4 --iterations=10
./lab2_add  --yield --threads=4 --iterations=20
./lab2_add  --yield --threads=4 --iterations=40
./lab2_add  --yield --threads=4 --iterations=80
./lab2_add  --yield --threads=4 --iterations=100
./lab2_add  --yield --threads=4 --iterations=1000
./lab2_add  --yield --threads=4 --iterations=10000
./lab2_add  --yield --threads=4 --iterations=100000
./lab2_add  --yield --threads=8 --iterations=10
./lab2_add  --yield --threads=8 --iterations=20
./lab2_add  --yield --threads=8 --iterations=40
./lab2_add  --yield --threads=8 --iterations=80
./lab2_add  --yield --threads=8 --iterations=100
./lab2_add  --yield --threads=8 --iterations=1000
./lab2_add  --yield --threads=8 --iterations=10000
./lab2_add  --yield --threads=8 --iterations=100000
./lab2_add  --yield --threads=12 --iterations=10
./lab2_add  --yield --threads=12 --iterations=20
./lab2_add  --yield --threads=12 --iterations=40
./lab2_add  --yield --threads=12 --iterations=80
./lab2_add  --yield --threads=12 --iterations=100
./lab2_add  --yield --threads=12 --iterations=1000
./lab2_add  --yield --threads=12 --iterations=10000
./lab2_add  --yield --threads=12 --iterations=100000

./lab2_add  --yield --threads=2 --iterations=100
./lab2_add  --yield --threads=2 --iterations=1000
./lab2_add  --yield --threads=2 --iterations=10000
./lab2_add  --yield --threads=2 --iterations=100000
./lab2_add  --yield --threads=8 --iterations=100
./lab2_add  --yield --threads=8 --iterations=1000
./lab2_add  --yield --threads=8 --iterations=10000
./lab2_add  --yield --threads=8 --iterations=100000
./lab2_add  --threads=2 --iterations=100
./lab2_add  --threads=2 --iterations=1000
./lab2_add  --threads=2 --iterations=10000
./lab2_add  --threads=2 --iterations=100000
./lab2_add  --threads=8 --iterations=100
./lab2_add  --threads=8 --iterations=1000
./lab2_add  --threads=8 --iterations=10000
./lab2_add  --threads=8 --iterations=100000

./lab2_add  --threads=1 --iterations=1
./lab2_add  --threads=1 --iterations=10
./lab2_add  --threads=1 --iterations=100
./lab2_add  --threads=1 --iterations=1000
./lab2_add  --threads=1 --iterations=10000
./lab2_add  --threads=1 --iterations=100000

./lab2_add  --yield --iterations=10000 --sync=m --threads=2
./lab2_add  --yield --iterations=10000 --sync=m --threads=4
./lab2_add  --yield --iterations=10000 --sync=m --threads=8
./lab2_add  --yield --iterations=10000 --sync=m --threads=12
./lab2_add  --yield --iterations=10000 --sync=c --threads=2
./lab2_add  --yield --iterations=10000 --sync=c --threads=4
./lab2_add  --yield --iterations=10000 --sync=c --threads=8
./lab2_add  --yield --iterations=10000 --sync=c --threads=12
./lab2_add  --yield --iterations=1000 --sync=s --threads=2
./lab2_add  --yield --iterations=1000 --sync=s --threads=4
./lab2_add  --yield --iterations=1000 --sync=s --threads=8
./lab2_add  --yield --iterations=1000 --sync=s --threads=12

./lab2_add  --iterations=10000 --threads=1
./lab2_add  --iterations=10000 --threads=2
./lab2_add  --iterations=10000 --threads=4
./lab2_add  --iterations=10000 --threads=8
./lab2_add  --iterations=10000 --threads=12
./lab2_add  --iterations=10000 --sync=m --threads=1
./lab2_add  --iterations=10000 --sync=m --threads=2
./lab2_add  --iterations=10000 --sync=m --threads=4
./lab2_add  --iterations=10000 --sync=m --threads=8
./lab2_add  --iterations=10000 --sync=m --threads=12
./lab2_add  --iterations=10000 --sync=s --threads=1
./lab2_add  --iterations=10000 --sync=s --threads=2
./lab2_add  --iterations=10000 --sync=s --threads=4
./lab2_add  --iterations=10000 --sync=s --threads=8
./lab2_add  --iterations=10000 --sync=s --threads=12
./lab2_add  --iterations=10000 --sync=c --threads=1
./lab2_add  --iterations=10000 --sync=c --threads=2
./lab2_add  --iterations=10000 --sync=c --threads=4
./lab2_add  --iterations=10000 --sync=c --threads=8
./lab2_add  --iterations=10000 --sync=c --threads=12